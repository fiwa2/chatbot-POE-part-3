package registration;

import javax.swing.JOptionPane;

public class Registration {
    private static String firstName;
    private static String lastName;
    private static String username;
    private static String password;
    private static String phoneNumber;

    // Getters and setters
    public static void setFirstName(String name) { firstName = name; }
    public static String getFirstName() { return firstName; }

    public static void setLastName(String surname) { lastName = surname; }
    public static String getLastName() { return lastName; }

    public static void setUserName(String user) { username = user; }
    public static String getUserName() { return username; }

    public static void setPassword(String pass) { password = pass; }
    public static String getPassword() { return password; }

    public static void setPhoneNumber(String phone) { phoneNumber = phone; }
    public static String getPhoneNumber() { return phoneNumber; }

    public static void main(String[] args) {
        // Load previously stored messages from JSON (if any)
        MessageManager.loadStoredMessagesFromJson();

        // --- Registration ---
        setFirstName(JOptionPane.showInputDialog("Enter first name:"));
        setLastName(JOptionPane.showInputDialog("Enter last name:"));

        String user;
        do {
            user = JOptionPane.showInputDialog("Enter username (≤5 chars and must contain '_'):");
            if (!Login.checkUserName(user)) {
                JOptionPane.showMessageDialog(null, "Username not formatted correctly.");
            }
        } while (!Login.checkUserName(user));
        setUserName(user);

        String pass;
        do {
            pass = JOptionPane.showInputDialog("Enter password (≥8 chars, 1 capital, 1 number, 1 special):");
            if (!Login.checkPasswordComplexity(pass)) {
                JOptionPane.showMessageDialog(null, "Password not formatted correctly.");
            }
        } while (!Login.checkPasswordComplexity(pass));
        setPassword(pass);

        String phone;
        do {
            phone = JOptionPane.showInputDialog("Enter phone number (+27 followed by 9 digits):");
            if (!Login.checkCellPhoneNumber(phone)) {
                JOptionPane.showMessageDialog(null, "Phone number incorrectly formatted.");
            }
        } while (!Login.checkCellPhoneNumber(phone));
        setPhoneNumber(phone);

        Login login = new Login();
        String regResult = login.registerUser(getUserName(), getPassword(), getPhoneNumber());
        JOptionPane.showMessageDialog(null, regResult);

        // --- Login ---
        boolean loggedIn = false;
        int tries = 0;
        while (!loggedIn && tries < 3) {
            String enteredUser = JOptionPane.showInputDialog("Enter username:");
            String enteredPass = JOptionPane.showInputDialog("Enter password:");
            login.setEnteredUsername(enteredUser);
            login.setEnteredPassword(enteredPass);

            if (login.loginUser()) {
                JOptionPane.showMessageDialog(null, login.returnLoginStatus());
                loggedIn = true;

                // --- Main Menu after login ---
                boolean running = true;
                while (running) {
                    String option = JOptionPane.showInputDialog("""
                            Welcome to QuickChat.
                            1) Send Messages
                            2) Show recently sent messages
                            3) Stored Messages
                            4) Quit
                            """);

                    if (option == null) break;

                    switch (option) {
                        case "1" -> sendMessages();
                        case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                        case "3" -> storedMessagesMenu();
                        case "4" -> running = false;
                        default -> JOptionPane.showMessageDialog(null, "Invalid option.");
                    }
                }
            } else {
                tries++;
                JOptionPane.showMessageDialog(null, "Login failed. Attempt " + tries + " of 3.");
            }
        }

        if (!loggedIn) {
            JOptionPane.showMessageDialog(null, "Maximum login attempts exceeded.");
        }
    }

    // Send messages (Part 2)
    private static void sendMessages() {
        int count = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send?"));
        for (int i = 1; i <= count; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27...):");
            if (!Message.checkRecipientCell(recipient)) {
                JOptionPane.showMessageDialog(null, "Invalid recipient number.");
                continue;
            }

            String text = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            Message msg = new Message(i, recipient, text);

            String lengthCheck = msg.checkMessageLength();
            if (!lengthCheck.equals("Message ready to send.")) {
                JOptionPane.showMessageDialog(null, lengthCheck);
                continue;
            }

            String choice = JOptionPane.showInputDialog("1) Send\n2) Disregard\n3) Store");
            int ch = Integer.parseInt(choice);
            String result = msg.sendMessage(ch);
            JOptionPane.showMessageDialog(null, result);
            JOptionPane.showMessageDialog(null, msg.toString());

            MessageManager.addMessage(msg, ch);
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());
    }

    // Stored Messages Menu (Part 3)
    private static void storedMessagesMenu() {
        String option = JOptionPane.showInputDialog("""
                Stored Messages Options:
                a) Display senders and recipients of all stored messages
                b) Display the longest stored message
                c) Search for a message ID
                d) Search for messages by recipient
                e) Delete a message using message hash
                f) Display full report of stored messages
                """);

        if (option == null) return;

        switch (option.toLowerCase()) {
            case "a" -> MessageManager.displayStoredSendersAndRecipients();
            case "b" -> MessageManager.displayLongestStoredMessage();
            case "c" -> MessageManager.searchStoredById();
            case "d" -> MessageManager.searchStoredByRecipient();
            case "e" -> MessageManager.deleteStoredMessageByHash();
            case "f" -> MessageManager.displayStoredReport();
            default -> JOptionPane.showMessageDialog(null, "Invalid option.");
        }
    }
}