package registration;

import javax.swing.JOptionPane;
import java.io.*;
import java.util.ArrayList;

public class MessageManager {
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static final String STORED_FILE = "stored_messages.json";

    // Add message to appropriate array (called after user choice)
    public static void addMessage(Message msg, int choice) {
        switch (choice) {
            case 1 -> sentMessages.add(msg);
            case 2 -> disregardedMessages.add(msg);
            case 3 -> {
                storedMessages.add(msg);
                storeMessageToJson(msg); // also save to file
            }
        }
    }

    // --- JSON Storage (Part 2 & 3) ---
    public static void storeMessageToJson(Message msg) {
        try (FileWriter fw = new FileWriter(STORED_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            String json = String.format("{\"id\":\"%s\",\"num\":%d,\"recipient\":\"%s\",\"text\":\"%s\",\"hash\":\"%s\"}",
                    msg.getMessageId(), msg.getMessageNumber(), msg.getRecipient(),
                    msg.getMessageText(), msg.getMessageHash());
            out.println(json);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message to JSON.");
        }
    }

    public static void loadStoredMessagesFromJson() {
        File file = new File(STORED_FILE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Very simple parse (assumes no commas/braces inside fields)
                String id = extractValue(line, "id");
                String numStr = extractValue(line, "num");
                String recipient = extractValue(line, "recipient");
                String text = extractValue(line, "text");
                String hash = extractValue(line, "hash");

                if (id != null && numStr != null && recipient != null && text != null) {
                    Message m = new Message(Integer.parseInt(numStr), recipient, text);
                    // Override auto-generated values with stored ones
                    java.lang.reflect.Field idField = Message.class.getDeclaredField("messageId");
                    idField.setAccessible(true);
                    idField.set(m, id);
                    java.lang.reflect.Field hashField = Message.class.getDeclaredField("messageHash");
                    hashField.setAccessible(true);
                    hashField.set(m, hash);
                    storedMessages.add(m);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading stored messages.");
        }
    }

    private static String extractValue(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start == -1) {
            // try numeric value without quotes
            search = "\"" + key + "\":";
            start = json.indexOf(search);
            if (start == -1) return null;
            start += search.length();
            int end = json.indexOf(",", start);
            if (end == -1) end = json.indexOf("}", start);
            return json.substring(start, end).replace("\"", "");
        }
        start += search.length();
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }

    // --- Part 3 Features (operate on storedMessages list) ---

    public static void displayStoredSendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages.");
            return;
        }
        StringBuilder sb = new StringBuilder("Sender: " + Registration.getUserName() + "\n");
        for (Message msg : storedMessages) {
            sb.append("Recipient: ").append(msg.getRecipient()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages.");
            return;
        }
        Message longest = storedMessages.get(0);
        for (Message msg : storedMessages) {
            if (msg.getMessageText().length() > longest.getMessageText().length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest stored message:\n" + longest.getMessageText());
    }

    public static void searchStoredById() {
        String id = JOptionPane.showInputDialog("Enter message ID:");
        for (Message msg : storedMessages) {
            if (msg.getMessageId().equals(id)) {
                JOptionPane.showMessageDialog(null, msg.toString());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    public static void searchStoredByRecipient() {
        String rec = JOptionPane.showInputDialog("Enter recipient number (+27...):");
        StringBuilder sb = new StringBuilder("Messages stored for " + rec + ":\n");
        boolean found = false;
        for (Message msg : storedMessages) {
            if (msg.getRecipient().equals(rec)) {
                sb.append(msg.getMessageText()).append("\n");
                found = true;
            }
        }
        if (found) JOptionPane.showMessageDialog(null, sb.toString());
        else JOptionPane.showMessageDialog(null, "No messages found for that recipient.");
    }

    public static void deleteStoredMessageByHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash:");
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).getMessageHash().equalsIgnoreCase(hash)) {
                storedMessages.remove(i);
                JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }

    public static void displayStoredReport() {
        if (storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages to report.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== Stored Message Report ===\n");
        for (Message msg : storedMessages) {
            sb.append(msg.toString()).append("\n-------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}