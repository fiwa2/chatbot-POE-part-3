package registration;

import java.util.Random;

public class Message {
    private static int totalMessages = 0;
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Message(int num, String rec, String text) {
        this.messageId = generateMessageId();
        this.messageNumber = num;
        this.recipient = rec;
        this.messageText = text;
        this.messageHash = createMessageHash();
    }

    private String generateMessageId() {
        Random r = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(r.nextInt(10));
        }
        return id.toString();
    }

    public static boolean checkRecipientCell(String number) {
        return number != null && number.matches("^\\+\\d{1,3}\\d{7,10}$");
    }

    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int extra = messageText.length() - 250;
            return "Message exceeds 250 characters by " + extra + ".";
        }
        return "Message ready to send.";
    }

    public String createMessageHash() {
        String[] words = messageText.split(" ");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String combined = firstWord + lastWord;
        return (messageId.substring(0, 2) + ":" + messageNumber + ":" + combined).toUpperCase();
    }

    public String sendMessage(int choice) {
        if (choice == 1) {
            totalMessages++;
            return "Message sent.";
        } else if (choice == 2) {
            return "Message discarded.";
        } else if (choice == 3) {
            // Store to JSON via MessageManager
            MessageManager.storeMessageToJson(this);
            return "Message stored.";
        }
        return "Invalid choice.";
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    @Override
    public String toString() {
        return "Message ID: " + messageId +
               "\nHash: " + messageHash +
               "\nRecipient: " + recipient +
               "\nMessage: " + messageText;
    }

    // Getters
    public String getMessageId() { return messageId; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public int getMessageNumber() { return messageNumber; }
}