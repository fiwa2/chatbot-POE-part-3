package registration;

public class Login {
    private String enteredUsername;
    private String enteredPassword;

    public static boolean checkUserName(String userName) {
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasNum = false, hasCap = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCap = true;
            if (Character.isDigit(c)) hasNum = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasNum && hasCap && hasSpecial;
    }

    public static boolean checkCellPhoneNumber(String num) {
        return num != null && num.matches("^\\+27[0-9]{9}$");
    }

    public String registerUser(String username, String password, String phoneNumber) {
        if (!checkUserName(username)) return "Username not formatted correctly.";
        if (!checkPasswordComplexity(password)) return "Password not formatted correctly.";
        if (!checkCellPhoneNumber(phoneNumber)) return "Phone number not formatted correctly.";
        return "Username, password, and phone successfully captured.";
    }

    public boolean loginUser() {
        return enteredUsername != null &&
               enteredUsername.equals(Registration.getUserName()) &&
               enteredPassword.equals(Registration.getPassword());
    }

    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + Registration.getFirstName() + " " + Registration.getLastName() + "!";
        } else {
            return "Username or password incorrect.";
        }
    }

    public void setEnteredUsername(String username) { enteredUsername = username; }
    public void setEnteredPassword(String password) { enteredPassword = password; }
}