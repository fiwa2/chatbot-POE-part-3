package registration;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    @Before
    public void setup() {
        Registration.setUserName(null);
        Registration.setPassword(null);
        Registration.setFirstName(null);
        Registration.setLastName(null);
    }

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(Login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_Invalid() {
        assertFalse(Login.checkUserName("kyle!!!!!!!"));
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        assertFalse(Login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(Login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        assertFalse(Login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testRegisterUser_Success() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username, password, and phone successfully captured.", result);
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        Login login = new Login();
        String result = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username not formatted correctly.", result);
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "password", "+27838968976");
        assertEquals("Password not formatted correctly.", result);
    }

    @Test
    public void testRegisterUser_InvalidPhone() {
        Login login = new Login();
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553");
        assertEquals("Phone number not formatted correctly.", result);
    }

    @Test
    public void testLoginUser_SuccessAndReturnLoginStatus() {
        Registration.setUserName("kyl_1");
        Registration.setPassword("Ch&&sec@ke99!");
        Registration.setFirstName("Kyle");
        Registration.setLastName("Smith");

        Login login = new Login();
        login.setEnteredUsername("kyl_1");
        login.setEnteredPassword("Ch&&sec@ke99!");

        assertTrue(login.loginUser());
        assertEquals("Welcome Kyle Smith!", login.returnLoginStatus());
    }

    @Test
    public void testLoginUser_Failure() {
        Registration.setUserName("kyl_1");
        Registration.setPassword("Ch&&sec@ke99!");

        Login login = new Login();
        login.setEnteredUsername("wrong");
        login.setEnteredPassword("wrong");

        assertFalse(login.loginUser());
        assertEquals("Username or password incorrect.", login.returnLoginStatus());
    }
}
