package registration;

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;

import static org.junit.Assert.*;

public class MessageIT {

    @Before
    public void resetMessageStatics() throws Exception {
        Field totalMessagesField = Message.class.getDeclaredField("totalMessages");
        totalMessagesField.setAccessible(true);
        totalMessagesField.setInt(null, 0);

        Field sentMessagesField = Message.class.getDeclaredField("sentMessages");
        sentMessagesField.setAccessible(true);
        ArrayList<String> empty = new ArrayList<>();
        sentMessagesField.set(null, empty);
    }

    @Test
    public void testCheckRecipientCell_Valid() {
        assertTrue(Message.checkRecipientCell("+27718693002"));
    }

    @Test
    public void testCheckRecipientCell_Invalid() {
        assertFalse(Message.checkRecipientCell("08575975889"));
    }

    @Test
    public void testCheckMessageLength_ShortMessage() {
        Message m = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight");
        assertEquals("Message ready to send.", m.checkMessageLength());
    }

    @Test
    public void testCheckMessageLength_TooLong() {
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) longMsg.append("a");
        Message m = new Message(1, "+27718693002", longMsg.toString());
        String res = m.checkMessageLength();
        assertEquals("Message exceeds 250 characters by 10.", res);
    }

    @Test
    public void testCreateMessageHash_FormatAndContents() {
        String text = "Hi Mike can you join us for dinner tonight";
        Message m = new Message(1, "+27718693002", text);
        String hashUpper = m.createMessageHash().toUpperCase();
        assertTrue("hash should start with two digits and ':1:'", hashUpper.matches("^\\d{2}:1:.*$"));
        assertTrue("hash should end with HITONIGHT", hashUpper.endsWith("HITONIGHT"));
    }

    @Test
    public void testSendMessage_IncrementsAndPrints() {
        Message m = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight");
        String res = m.sendMessage(1);
        assertEquals("Message sent.", res);
        assertEquals(1, Message.returnTotalMessages());
    }

    @Test
    public void testSendMessage_DiscardAndStore() {
        Message m1 = new Message(1, "+27718693002", "Message one");
        assertEquals("Message discarded.", m1.sendMessage(2));
        Message m2 = new Message(2, "+27718693002", "Message two");
        assertEquals("Message stored.", m2.sendMessage(3));
        assertEquals(0, Message.returnTotalMessages());
    }
}
